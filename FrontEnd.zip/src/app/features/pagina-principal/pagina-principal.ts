import {Component, signal} from '@angular/core';

@Component({
  selector: 'app-pagina-principal',
  imports: [],
  templateUrl: './pagina-principal.html',
  styleUrl: './pagina-principal.scss',
})
export class PaginaPrincipal {

    openCategoria = signal<boolean>(false);

    toggleCategoria() {
        this.openCategoria.update(state => !state);
    }
}
