import { Component } from '@angular/core';
import {Header} from "./components/header/header";
import {RouterOutlet} from "@angular/router";
import {Footer} from "./components/footer/footer";

@Component({
  selector: 'app-main-layout',
    imports: [
        Header,
        RouterOutlet,
        Footer
    ],
  templateUrl: './main-layout.html',
  styleUrl: './main-layout.scss',
    standalone: true
})
export class MainLayout {

}
