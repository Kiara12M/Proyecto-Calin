import { Routes } from '@angular/router';

export const routes: Routes = [

    {
        path: '',
        loadComponent: () => import("./layouts/main-layout/main-layout").then(c => c.MainLayout),
        children: [
            {
                path: '',
                loadComponent: () => import("./features/pagina-principal/pagina-principal").then(c => c.PaginaPrincipal),
            },
            {
              path: 'login',
              loadComponent:()=> import("./layouts/main-layout/components/login/login").then(c => c.Login),
            },
            {
                path: 'register',
                loadComponent:() => import("./layouts/main-layout/components/register/register").then(c => c.Register),
            }
        ]
    },
];
